import React from "react";
import { Wrapper } from "../Style/MobileAppStyle";

function MobileApp() {
  return (
    <>
      <Wrapper>
        <div className="main-div">
          <div className="inner-div"></div>
        </div>
      </Wrapper>
    </>
  );
}

export default MobileApp;
