import styled from "styled-components";

export const Wrapper = styled.div`
  .main-div {
    display: flex;
    -webkit-box-pack: center;
    justify-content: center;
    width: 100%;
    background-color: rgb(255, 251, 247);
  }
`;
